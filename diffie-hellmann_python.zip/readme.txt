This app explains the Diffie-Hellmann-Encoding with a simple example

Music by Louswan